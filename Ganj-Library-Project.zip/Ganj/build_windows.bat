@echo off
REM ===== Local Windows build (Windows 7+ compatible, 32-bit) -> dist\GanjLibrarySetup.exe =====
REM Requirements: CMake, Ninja, Inno Setup 6, Qt 5.15.2 with the "MinGW 8.1.0 32-bit" component
REM (install both from the Qt online installer). Adjust the two paths below if needed.
setlocal
set QT_DIR=C:\Qt\5.15.2\mingw81_32
set MINGW_DIR=C:\Qt\Tools\mingw810_32
set PATH=%MINGW_DIR%\bin;%QT_DIR%\bin;%PATH%

cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_COMPILER=%MINGW_DIR%/bin/g++.exe -DCMAKE_RC_COMPILER=%MINGW_DIR%/bin/windres.exe -DCMAKE_PREFIX_PATH=%QT_DIR% || goto :fail
cmake --build build -- -k 0 || goto :fail

if exist deploy rmdir /s /q deploy
mkdir deploy
copy build\Ganj.exe deploy\ >nul
windeployqt --release --no-translations --no-system-d3d-compiler --no-opengl-sw --no-angle deploy\Ganj.exe || goto :fail
for %%D in (libgcc_s_dw2-1.dll libstdc++-6.dll libwinpthread-1.dll) do if not exist deploy\%%D copy "%MINGW_DIR%\bin\%%D" deploy\ >nul
if exist resources\fonts xcopy resources\fonts deploy\fonts /E /I /Y >nul

"%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" installer\ganj.iss || goto :fail
echo.
echo Done: dist\GanjLibrarySetup.exe
exit /b 0

:fail
echo.
echo BUILD FAILED
exit /b 1
