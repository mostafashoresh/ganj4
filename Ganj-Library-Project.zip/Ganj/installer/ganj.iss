[Setup]
AppId={{B6E1F0D2-5B7A-4B8E-9C61-3A6E5F1D7A21}
AppName=Ganj Library
AppVersion=1.0.0
AppPublisher=Tip 116 Mechanized Infantry
DefaultDirName={autopf}\GanjLibrary
DefaultGroupName=Ganj Library
OutputDir=..\dist
OutputBaseFilename=GanjLibrarySetup
SetupIconFile=..\resources\ganj.ico
UninstallDisplayIcon={app}\Ganj.exe
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
MinVersion=6.1
PrivilegesRequired=admin

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional icons:"

[Files]
Source: "..\deploy\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\Ganj Library"; Filename: "{app}\Ganj.exe"
Name: "{autodesktop}\Ganj Library"; Filename: "{app}\Ganj.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\Ganj.exe"; Description: "Launch Ganj Library"; Flags: nowait postinstall skipifsilent
