#include "data/CategoryRepository.h"

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QVariant>

#include "data/DbUtil.h"
#include "util/TextUtil.h"

QList<Category> CategoryRepository::list() const {
    QList<Category> out;
    QSqlQuery q;
    q.prepare(
        "SELECT c.id, c.name,"
        " (SELECT COUNT(*) FROM books b WHERE b.category = c.name COLLATE NOCASE)"
        " FROM categories c ORDER BY c.name COLLATE NOCASE");
    if (!q.exec()) return out;
    while (q.next()) {
        Category c;
        c.id = q.value(0).toLongLong();
        c.name = q.value(1).toString();
        c.bookCount = q.value(2).toInt();
        out.append(c);
    }
    return out;
}

bool CategoryRepository::add(const QString& name, QString* error) const {
    const QString n = TextUtil::normalize(name);
    if (n.isEmpty()) {
        DbUtil::setError(error, "نام دسته‌بندی را وارد کنید.");
        return false;
    }
    QSqlQuery check;
    check.prepare("SELECT 1 FROM categories WHERE name = ?");
    check.addBindValue(n);
    if (check.exec() && check.next()) {
        DbUtil::setError(error, "این دسته‌بندی قبلاً وجود دارد.");
        return false;
    }
    QSqlQuery q;
    q.prepare("INSERT INTO categories(name) VALUES(?)");
    q.addBindValue(n);
    if (!q.exec()) {
        DbUtil::setError(error, q);
        return false;
    }
    return true;
}

bool CategoryRepository::rename(qint64 id, const QString& newName, QString* error) const {
    const QString n = TextUtil::normalize(newName);
    if (n.isEmpty()) {
        DbUtil::setError(error, "نام دسته‌بندی را وارد کنید.");
        return false;
    }

    QSqlQuery current;
    current.prepare("SELECT name FROM categories WHERE id = ?");
    current.addBindValue(id);
    if (!current.exec() || !current.next()) {
        DbUtil::setError(error, "دسته‌بندی پیدا نشد.");
        return false;
    }
    const QString oldName = current.value(0).toString();

    QSqlQuery dup;
    dup.prepare("SELECT 1 FROM categories WHERE name = ? AND id <> ?");
    dup.addBindValue(n);
    dup.addBindValue(id);
    if (dup.exec() && dup.next()) {
        DbUtil::setError(error, "دسته‌بندی دیگری با این نام وجود دارد.");
        return false;
    }

    QSqlDatabase db = QSqlDatabase::database();
    db.transaction();
    QSqlQuery a;
    a.prepare("UPDATE categories SET name = ? WHERE id = ?");
    a.addBindValue(n);
    a.addBindValue(id);
    QSqlQuery b;
    b.prepare("UPDATE books SET category = ? WHERE category = ? COLLATE NOCASE");
    b.addBindValue(n);
    b.addBindValue(oldName);
    if (!a.exec() || !b.exec()) {
        DbUtil::setError(error, a.lastError().isValid() ? a.lastError().text() : b.lastError().text());
        db.rollback();
        return false;
    }
    db.commit();
    return true;
}

bool CategoryRepository::remove(qint64 id, QString* error) const {
    QSqlQuery current;
    current.prepare("SELECT name FROM categories WHERE id = ?");
    current.addBindValue(id);
    if (!current.exec() || !current.next()) {
        DbUtil::setError(error, "دسته‌بندی پیدا نشد.");
        return false;
    }
    const QString name = current.value(0).toString();

    QSqlDatabase db = QSqlDatabase::database();
    db.transaction();
    QSqlQuery a;
    a.prepare("UPDATE books SET category = '' WHERE category = ? COLLATE NOCASE");
    a.addBindValue(name);
    QSqlQuery b;
    b.prepare("DELETE FROM categories WHERE id = ?");
    b.addBindValue(id);
    if (!a.exec() || !b.exec()) {
        DbUtil::setError(error, a.lastError().isValid() ? a.lastError().text() : b.lastError().text());
        db.rollback();
        return false;
    }
    db.commit();
    return true;
}

void CategoryRepository::ensure(const QString& name) {
    const QString n = TextUtil::normalize(name);
    if (n.isEmpty()) return;
    QSqlQuery q;
    q.prepare("INSERT OR IGNORE INTO categories(name) VALUES(?)");
    q.addBindValue(n);
    q.exec();
}
