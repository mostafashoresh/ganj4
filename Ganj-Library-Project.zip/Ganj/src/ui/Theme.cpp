#include "ui/Theme.h"

#include <QApplication>
#include <QCoreApplication>
#include <QDir>
#include <QFile>
#include <QFont>
#include <QFontDatabase>
#include <QImage>
#include <QPainter>
#include <QPainterPath>
#include <QStandardPaths>

namespace {

// Style sheets can only show arrows from real image files, so the two small
// triangle icons used by spin boxes and combo boxes are drawn here and saved to AppData.
void makeArrow(const QString& path, bool up) {
    QImage img(16, 16, QImage::Format_ARGB32);
    img.fill(Qt::transparent);
    QPainter p(&img);
    p.setRenderHint(QPainter::Antialiasing);
    p.setPen(Qt::NoPen);
    p.setBrush(QColor("#12322a"));
    QPainterPath triangle;
    if (up) {
        triangle.moveTo(3, 11);
        triangle.lineTo(13, 11);
        triangle.lineTo(8, 4.5);
    } else {
        triangle.moveTo(3, 5);
        triangle.lineTo(13, 5);
        triangle.lineTo(8, 11.5);
    }
    triangle.closeSubpath();
    p.drawPath(triangle);
    p.end();
    img.save(path, "PNG");
}

}  // namespace

namespace Theme {

void loadFonts() {
    QDir dir(QCoreApplication::applicationDirPath() + "/fonts");
    const QStringList files = dir.entryList({"*.ttf", "*.otf"}, QDir::Files);
    for (const QString& file : files)
        QFontDatabase::addApplicationFont(dir.absoluteFilePath(file));
}

void apply(QApplication& app) {
    app.setStyle("Fusion");

    const QString iconDir =
        QStandardPaths::writableLocation(QStandardPaths::AppDataLocation) + "/icons";
    QDir().mkpath(iconDir);
    makeArrow(iconDir + "/arrow-up.png", true);
    makeArrow(iconDir + "/arrow-down.png", false);

    QFile qss(":/style.qss");
    if (qss.open(QIODevice::ReadOnly)) {
        QString sheet = QString::fromUtf8(qss.readAll());
        sheet.replace("%ICONDIR%", iconDir);
        app.setStyleSheet(sheet);
    }

    QFont font("Segoe UI", 10);
    font.setFamilies({"Vazirmatn", "Segoe UI", "Tahoma"});
    app.setFont(font);
}

}  // namespace Theme
