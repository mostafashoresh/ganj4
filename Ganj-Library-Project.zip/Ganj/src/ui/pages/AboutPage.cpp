#include "ui/pages/AboutPage.h"

#include <QCoreApplication>
#include <QFrame>
#include <QHBoxLayout>
#include <QLabel>
#include <QVBoxLayout>

#include "util/TextUtil.h"

namespace {

QLabel* makeLabel(const QString& text, const char* objectName, bool wrap = false) {
    auto* label = new QLabel(text);
    label->setObjectName(objectName);
    label->setAlignment(Qt::AlignCenter);
    label->setWordWrap(wrap);
    return label;
}

}  // namespace

AboutPage::AboutPage(QWidget* parent) : Page(parent) {
    auto* title = new QLabel("درباره ما");
    title->setObjectName("PageTitle");

    auto* card = new QFrame;
    card->setObjectName("Card");
    card->setMaximumWidth(780);
    auto* c = new QVBoxLayout(card);
    c->setContentsMargins(44, 34, 44, 34);
    c->setSpacing(10);

    auto* goldLine = new QFrame;
    goldLine->setObjectName("GoldLine");
    goldLine->setFixedSize(90, 3);

    const QString thanks =
        "با نهایت احترام و سپاس، از فرمانده محترم تیپ، جناب سرتیپ دوم امیر جلال بهاری‌فر، "
        "به‌خاطر حمایت‌ها، توجه و راهنمایی‌های ارزشمندشان در فراهم‌کردن بستر تهیه و راه‌اندازی "
        "این سامانه صمیمانه قدردانی می‌کنیم. امید است این مجموعه گامی کوچک در راستای "
        "ارتقای فرهنگ مطالعه و خدمت‌رسانی بهتر به همه‌ی پرسنل عزیز تیپ باشد.";

    c->addWidget(makeLabel("سامانه مدیریت کتابخانه گنج", "AboutName"));
    c->addSpacing(4);
    c->addWidget(makeLabel("تهیه و طراحی شده در\nتیپ ۱۱۶ پیاده مکانیزه شهید سرلشگر علی صفوی",
                           "AboutUnit", true));
    c->addSpacing(8);
    c->addWidget(goldLine, 0, Qt::AlignHCenter);
    c->addSpacing(12);
    c->addWidget(makeLabel("فرمانده تیپ ۱۱۶ پیاده مکانیزه شهید سرلشگر علی صفوی", "AboutRole", true));
    c->addWidget(makeLabel("سرتیپ دوم امیر جلال بهاری‌فر", "AboutCommander"));
    c->addSpacing(16);
    c->addWidget(makeLabel(thanks, "AboutBody", true));
    c->addSpacing(12);
    c->addWidget(makeLabel("نسخه " + TextUtil::toPersianDigits(QCoreApplication::applicationVersion()),
                           "AboutRole"));

    auto* row = new QHBoxLayout;
    row->addStretch(1);
    row->addWidget(card, 4);
    row->addStretch(1);

    auto* layout = new QVBoxLayout(this);
    layout->setContentsMargins(28, 24, 28, 20);
    layout->addWidget(title);
    layout->addStretch(1);
    layout->addLayout(row);
    layout->addStretch(2);
}
