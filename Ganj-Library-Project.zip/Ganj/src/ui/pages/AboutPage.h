#pragma once
#include "ui/pages/Page.h"

// "About us" screen: credits and a thank-you note to the brigade commander.
class AboutPage : public Page {
    Q_OBJECT
public:
    explicit AboutPage(QWidget* parent = nullptr);
    void refresh() override {}   // static content
};
