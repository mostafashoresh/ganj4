#pragma once
#include "data/CategoryRepository.h"
#include "ui/pages/Page.h"

class QLabel;
class QLineEdit;
class QTableWidget;

class CategoriesPage : public Page {
    Q_OBJECT
public:
    explicit CategoriesPage(QWidget* parent = nullptr);
    void refresh() override;

private slots:
    void addCategory();
    void renameSelected();
    void deleteSelected();

private:
    CategoryRepository repo_;
    QLineEdit* newName_;
    QTableWidget* table_;
    QLabel* count_;
};
